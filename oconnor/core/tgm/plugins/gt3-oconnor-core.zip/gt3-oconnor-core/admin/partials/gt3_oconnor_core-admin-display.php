<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://themeforest.net/user/gt3themes
 * @since      1.0.0
 *
 * @package    Gt3_oconnor_core
 * @subpackage Gt3_oconnor_core/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
